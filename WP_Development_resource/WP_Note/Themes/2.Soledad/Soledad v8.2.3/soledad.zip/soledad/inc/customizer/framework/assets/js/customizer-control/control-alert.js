wp.customize.controlConstructor['soledad-fw-alert'] = wp.customize.controlConstructor.default.extend({});
