<?php
/**
 * @author      SoledadFWtheme
 * @license     https://opensource.org/licenses/MIT
 */
namespace SoledadFW\Customizer\Section;

/**
 * Default Settings
 */
class Helper_Section extends \WP_Customize_Section {}

