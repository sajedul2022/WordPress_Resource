<?php
/**
 * leadengine functions file
 *
 * @package leadengine
 * by KeyDesign
 */

require_once( get_template_directory() . '/core/init.php');
update_option( 'keydesign-verify','yes');
update_option('envato_purchase_code_21514338','86007fe7c96b81e21230c92332cec962');

 // -------------------------------------
 // Edit below this line
 // -------------------------------------