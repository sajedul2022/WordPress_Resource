<?php

/**
 * linoor functions for getting inline styles from theme customizer
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package linoor
 */

if (!function_exists('linoor_theme_customizer_styles')) :
    function linoor_theme_customizer_styles()
    {

        // linoor color option

        $linoor_inline_style = '';
        $linoor_inline_style .= '
        :root {
            --thm-base: ' . get_theme_mod('theme_base_color', sanitize_hex_color('#ffaa17')) . ';
            --thm-base-rgb: ' . linoor_hex_to_rgb(get_theme_mod('theme_base_color', sanitize_hex_color('#ffaa17'))) . ';
            --thm-black: ' . get_theme_mod('theme_black_color', sanitize_hex_color('#222429')) . ';
            --thm-black-rgb: ' . linoor_hex_to_rgb(get_theme_mod('theme_black_color', sanitize_hex_color('#222429'))) . ';
            --thm-text: ' . get_theme_mod('theme_text_color', sanitize_hex_color('#686a6f')) . ';
        }';

        $linoor_inner_banner_bg = get_theme_mod('page_header_bg_image');
        $linoor_inline_style .= '.page-banner .image-layer { background-image: url(' . $linoor_inner_banner_bg . '); } ';

        $body_font = !empty(get_post_meta(get_the_ID(), 'linoor_body_font', true)) ? get_post_meta(get_the_ID(), 'linoor_body_font', true) : get_theme_mod('theme_body_font');
        $dynamic_body_font = isset($_GET['theme_body_font']) ? $_GET['theme_body_font'] : $body_font;

        $heading_font = !empty(get_post_meta(get_the_ID(), 'linoor_heading_font', true)) ? get_post_meta(get_the_ID(), 'linoor_heading_font', true) : get_theme_mod('theme_heading_font');
        $dynamic_heading_font = isset($_GET['theme_heading_font']) ? $_GET['theme_heading_font'] : $heading_font;


        if (!empty($dynamic_heading_font)) {
            $linoor_inline_style .= ':root { --thm-font: ' . $dynamic_heading_font . ' }';
        }

        if (!empty($dynamic_body_font)) {
            $linoor_inline_style .= ':root { --thm-b-font: ' . $dynamic_body_font . ' }';
        }

        if (is_page()) {

            $linoor_page_base_color = empty(get_post_meta(get_the_ID(), 'linoor_base_color', true)) ? get_theme_mod('theme_base_color', sanitize_hex_color('#ffaa17')) : get_post_meta(get_the_ID(), 'linoor_base_color', true);

            $linoor_page_black_color = empty(get_post_meta(get_the_ID(), 'linoor_black_color', true)) ? get_theme_mod('theme_black_color', sanitize_hex_color('#222429')) : get_post_meta(get_the_ID(), 'linoor_black_color', true);

            $linoor_page_text_color = empty(get_post_meta(get_the_ID(), 'linoor_text_color', true)) ? get_theme_mod('theme_text_color', sanitize_hex_color('#686a6f')) : get_post_meta(get_the_ID(), 'linoor_text_color', true);

            $linoor_inline_style .= '
            :root {
                --thm-base: ' . $linoor_page_base_color . ';
                --thm-base-rgb: ' . linoor_hex_to_rgb($linoor_page_base_color) . ';
                --thm-black: ' . $linoor_page_black_color . ';
                --thm-black-rgb: ' . linoor_hex_to_rgb($linoor_page_black_color) . ';
                --thm-text: ' . $linoor_page_text_color . ';
            }';

            $linoor_page_header_bg = empty(get_post_meta(get_the_ID(), 'linoor_set_header_image', true)) ? get_theme_mod('page_header_bg_image') : get_post_meta(get_the_ID(), 'linoor_set_header_image', true);

            $linoor_inline_style .= '.page-banner .image-layer { background-image: url(' . $linoor_page_header_bg . '); }';
        }


        // dynamic preloader
        $linoor_meta_preloader_image = get_post_meta(get_the_ID(), 'linoor_preloader_image', true);
        $linoor_customizer_preloader_image = get_theme_mod('preloader_image');
        $linoor_preloader_image = !empty($linoor_meta_preloader_image) ? $linoor_meta_preloader_image : $linoor_customizer_preloader_image;
        if (!empty($linoor_preloader_image)) {
            $linoor_inline_style .= '.preloader .icon {
                background-image: url(' . $linoor_preloader_image . ');
            }';
        }

        wp_add_inline_style('linoor-main', $linoor_inline_style);
    }
endif;

add_action('wp_enqueue_scripts', 'linoor_theme_customizer_styles');
